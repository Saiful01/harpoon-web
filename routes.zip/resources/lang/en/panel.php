<?php

return [
    'site_title' => 'DblCeramics',

];
