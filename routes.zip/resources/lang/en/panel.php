<?php

return [
    'site_title' => 'Harpoon',

];
