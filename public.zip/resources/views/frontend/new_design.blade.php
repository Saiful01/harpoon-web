<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="icon" type="image/png" sizes="32x32" href="/assets/images/dbl-ceramics-limited.png">
    <title>DBL CERAMICS BUSINESS CONFERENCE 2024</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            font-size: 24px;
            text-align: center;
            margin-bottom: 20px;
        }

        .upload-section, .preview-section, .instructions {
            margin-bottom: 30px;
        }

        .upload-box {
            border: 2px dashed #ccc;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .upload-box:hover {
            background-color: #f9f9f9;
        }

        .upload-box input[type="file"] {
            display: none;
        }

        .preview-frame {
            position: relative;
            width: 100%;
            max-width: 450px;
            height: 450px;
            margin: 0 auto;
            border: 2px solid #ccc;
            border-radius: 8px;
            background: #fff;
            overflow: hidden;
        }

        .preview-frame img {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('/assets/images/FaceBook-Profile.png') no-repeat center center;
            background-size: cover;
            pointer-events: none;
            z-index: 10;
        }

        .tools {
            text-align: center;
            margin-top: 20px;
        }

        .tools label {
            margin-right: 10px;
        }

        .tools input[type="range"] {
            width: 300px;
            margin-top: 10px;
        }

        .download-btn {
            text-align: center;
            margin-top: 20px;
        }

        .download-btn button {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .download-btn button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>DBL CERAMICS BUSINESS CONFERENCE 2024</h1>

    <div class="instructions">
        <ol>
            <li><strong>Add your image here:</strong></li>
            <div class="upload-section">
                <div class="upload-box" onclick="document.getElementById('fileInput').click();">
                    Drop files here or click to upload.
                    <input type="file" id="fileInput" accept="image/*">
                </div>
            </div>
            <li><strong>Use the photo tools to scale, rotate, and position your image.</strong></li>
            <li><strong>Click to download your custom photo!</strong></li>
            <li>Post on social media using the hastag <strong>#শ্রেষ্ঠত্বেরনতুনদিগন্ত <br>#Business_conference_2024 #dblceramics #Brightceramics</strong>.</li>
        </ol>
    </div>

    <div class="preview-section">
        <div class="preview-frame" id="previewFrame">
            <div class="overlay"></div>
        </div>

        <div class="tools">
            <div>
                <label for="rotation">Rotation:</label>
                <input type="range" id="rotation" min="-180" max="180" value="0">
            </div>

            <div>
                <label for="scale">Scale:</label>
                <input type="range" id="scale" min="1" max="3" step="0.1" value="1">
            </div>
        </div>

        <div class="download-btn">
            <button id="downloadBtn">Download your photo</button>
        </div>
    </div>
</div>

<script>
    const fileInput = document.getElementById('fileInput');
    const previewFrame = document.getElementById('previewFrame');
    const rotationInput = document.getElementById('rotation');
    const scaleInput = document.getElementById('scale');
    const downloadBtn = document.getElementById('downloadBtn');

    let uploadedImage = null;

    // Load and display uploaded image
    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(event) {
                const img = new Image();
                img.src = event.target.result;
                img.id = 'uploadedImage';
                uploadedImage = img;

                // Clear existing preview and add the new image
                previewFrame.innerHTML = '<div class="overlay"></div>';
                previewFrame.appendChild(img);
                applyTransform();
            };
            reader.readAsDataURL(file);
        }
    });

    // Apply transformations (rotation and scale)
    function applyTransform() {
        if (uploadedImage) {
            const rotation = rotationInput.value;
            const scale = scaleInput.value;
            uploadedImage.style.transform = `translate(-50%, -50%) rotate(${rotation}deg) scale(${scale})`;
        }
    }

    rotationInput.addEventListener('input', applyTransform);
    scaleInput.addEventListener('input', applyTransform);

    // Download the customized image
    downloadBtn.addEventListener('click', () => {
        if (!uploadedImage) {
            alert('Please upload an image first!');
            return;
        }

        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const overlay = new Image();
        overlay.src = '/assets/images/FaceBook-Profile.png';

        // Set canvas dimensions
        canvas.width = 1000;
        canvas.height = 1000;

        overlay.onload = () => {
            // Fill background with white
            ctx.fillStyle = '#fff';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            // Draw uploaded image with transformations
            const imgWidth = uploadedImage.naturalWidth;
            const imgHeight = uploadedImage.naturalHeight;
            ctx.translate(canvas.width / 2, canvas.height / 2);
            ctx.rotate((rotationInput.value * Math.PI) / 180);
            ctx.scale(scaleInput.value, scaleInput.value);
            ctx.drawImage(uploadedImage, -imgWidth / 2, -imgHeight / 2, imgWidth, imgHeight);
            ctx.setTransform(1, 0, 0, 1, 0, 0);

            // Draw overlay
            ctx.drawImage(overlay, 0, 0, canvas.width, canvas.height);

            // Trigger download
            const link = document.createElement('a');
            link.download = 'custom_image.png';
            link.href = canvas.toDataURL('image/png');
            link.click();
        };
    });
</script>
</body>
</html>
